package com.furqoncreative.githubusers3.utils

const val DEFAULT_TIME = "09:00"
const val TYPE_REPEATING = "RepeatingAlarm"
const val EXTRA_TYPE = "type"
const val ID_NOTIF = 101
const val TIME_FORMAT = "HH:mm"
